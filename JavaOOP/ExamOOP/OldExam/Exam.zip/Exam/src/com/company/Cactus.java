package com.company;

public class Cactus extends  Posev{
    public Cactus(String name, int currentAge) {
        super(name, 3, currentAge);
    }
}
