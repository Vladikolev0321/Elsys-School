package com.company;

public class Fruit extends  Posev{
    public Fruit(String name, int currentAge) {
        super(name, 4, currentAge);
    }
    public void polivane(){
        setPolqtoThisDay(true);
    }
}
