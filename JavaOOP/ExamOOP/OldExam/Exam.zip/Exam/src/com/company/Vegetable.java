package com.company;

public class Vegetable extends Posev{

    public Vegetable(String name, int currentAge) {
        super(name, 2, currentAge);
    }
    public void polivane(){
        setPolqtoThisDay(true);
    }

}
