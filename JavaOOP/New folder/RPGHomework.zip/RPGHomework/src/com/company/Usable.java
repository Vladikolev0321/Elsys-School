package com.company;

public interface Usable {
    void use(Character source, Character target);
}
