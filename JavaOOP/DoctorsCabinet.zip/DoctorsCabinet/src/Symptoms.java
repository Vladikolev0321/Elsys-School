public enum Symptoms {
    Cough,
    HighTemperature,
    ProblemsWithBreathing,
    Vommiting,
    Headache,
}
