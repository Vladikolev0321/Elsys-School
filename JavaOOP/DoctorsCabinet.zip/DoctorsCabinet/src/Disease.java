import java.lang.reflect.Array;

public class Disease {
    private String name;
    private String[] symptoms;

    public Disease(String name, String[] symptoms) {
        this.name = name;
        this.symptoms = symptoms;
    }

}
