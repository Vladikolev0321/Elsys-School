package com.company;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TriangleTest {

    @Test
    void checkCollision() {
    }

    @Test
    void getPoints() {

    }
}