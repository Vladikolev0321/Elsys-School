package com.company;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HardDriveTest {

    @Test
    void getConsumption() {

    }
}