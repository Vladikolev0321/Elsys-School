package com.company;

public interface IPart {
    public PowerData getConsumption();
}
