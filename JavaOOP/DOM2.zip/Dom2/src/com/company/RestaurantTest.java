package com.company;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RestaurantTest {

    @BeforeEach
    void setUp() {
    }

    @Test

    void addOrder() {
    }

    @Test
    void completeOrder() {
    }

    @Test
    void addChef() {
    }

    @Test
    void addWaiter() {
    }
}