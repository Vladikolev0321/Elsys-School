package com.company;

public class Workout {
    private String name;
    private String type;

    public String getType() {
        return type;
    }

    public Workout(String name, String type) {
        this.name = name;
        this.type = type;
    }
}
